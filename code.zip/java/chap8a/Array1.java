// A 1d array
public class Array1 {
    public static void main(String[] args) {
        int[] a1 = {10,20,30,40,50};
        for (int i = 0; i < a1.length; ++i)
            System.out.print(a1[i] + " ");
        System.out.println();
    }
}

