// hello.cpp
#include <iostream>
using namespace std;

int main() {
    cout << "Hello, world" << endl;
}

